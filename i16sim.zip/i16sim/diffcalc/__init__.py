"""Top-level package for diffcalc-core."""

__author__ = """Diamond Light Source Ltd. - Scientific Software"""
__email__ = "scientificsoftware@diamond.ac.uk"
__version__ = "0.3.0"
