

def simbl (hkl_ob=None,
           val=None, 
           debug=False, 
           filename='/dls_sw/i16/software/python/i16sim/gda.i16sim.txt'):
    """
    in: (sixc, [phi, chi, eta, mu, delta, gam]) or (hkl, [h,k,l])
    return: True if 'sim (hkl_ob, val)' did not throw an error
    out: usual simulation outputs and the simulated diffractometer state is stored in a file.
    
    If called without parameters or a simulation is not possible, the current state is saved instead
    
    debug - if the function should print the saved diffractometer state
    filename - location to write diffractometer state
    
    
    
    An extension of the sim command. 
    Simulates the given move and 
    stores the simulated position in a file that the i16sim simulation can import.  
    
    Author: Aurys Silinga
    19/08/2021
    tested on 20/08/2021, cm28156-10, i16
    
    Examples:
    simbl(hkl, [1,1,1]) # simulates a move to [1,1,1] and saves the [1,1,1] position to a file
    simbl() # saves current position to file
    simbl(debug=True) # saves current position and print( ub, sixc, en, lattice, constraints)
    """
    move_possible=False
    
    #Run 'sim' command if parameters are given
    if not (hkl_ob is None or val is None):
        try:
            sim(hkl_ob,val)
            move_possible=True
        except Exception as e:
            print(e)
            print('Full simulation not possible')
            hkl_ob=None #use current position
        
    #get pseudomotor rotations
    try:
        if (hkl_ob is None or val is None):
            #use current position
            [p,c,e,m,d,g]=sixc()#phi,chi,eta,mu,delta,gam
            pos_now=[m,d,g,e,c,p] #convert to [mu,del,gam,eta,chi,phi]
            print('Writing current position:')
            print(sixc)
            
        elif (hkl_ob==hkl):
            p,va=hklcalc.hklToAngles(val[0],val[1],val[2],wl())
            pos_now=p.totuple() #[mu,delta,gam,eta,chi,phi]
            
        elif (hkl_ob==sixc):
            [p,c,e,m,d,g]=val#phi,chi,eta,mu,delta,gam
            pos_now=[m,d,g,e,c,p] #convert to [mu,del,gam,eta,chi,phi]
    except:
        pos_now=None
        
    #copy UB elements 
    try:
        ub_now=ubcalc.UB.tolist()
    except:
        ub_now=None
        
    #get energy
    try:
        en_now=en()
    except:
        en_now=None
    
    #get constraints
    try:
        con_now=constraint_manager._constrained
        if con_now=={}:
            con_now=None
    except:
        con_now=None
    
    #get lattice
    try:
        latt_now=ubcalc._state.crystal.getLattice()
    except:
        latt_now=None
    
    #save state to file
    with open (filename,'w') as f:
    
        if not ub_now is None:
            f.write('ub\n')
            for row in ub_now:
                for el in row:
                    f.write(str(el)+' ')
                f.write('\n')
                
        if not pos_now is None:
            f.write('sixc\n')
            for el in pos_now:
                f.write(str(el)+' ')
            f.write('\n')
        
        if not en_now is None:
            f.write('en\n')
            f.write(str(en_now)+'\n')
        
        if not latt_now is None:
            f.write('lattice\n')
            f.write(str(latt_now[0])+'\n')
            for el in latt_now[1:]:
                f.write(str(el)+' ')
            f.write('\n')
        
        if not con_now is None:
            f.write('con\n')
            for key in con_now:
                f.write(str(key)+' '+str(con_now[key])+'\n')
    
    print('')
    print("Finished writing to "+filename)
    print('')
    
    #debug printing
    if debug:
        print('debug:')
        state_names=['ub','pos:[mu,del,gam,eta,chi,phi]','en','lattice','con']
        state_now=(ub_now, pos_now, en_now, latt_now, con_now)
        for i in range(len(state_now)):
            print(state_names[i],state_now[i])
        print('')
        
    return (move_possible)

   
#tests
#simbl(sixc,[4,5,6,3,2,1]) #simulates pos=[1,2,3,4,5,6]
#print(simbl (hkl ,[1, 1, 1],debug=False) )
#simbl(debug=True)
#simbl (hkl ,[1, 1, 1],debug=True) 
#simbl(sixc,[-16.426292485123145, 9.670349170311017, 20.407578482550853, 0.0, 40.815156965102, 0.0]) #goes to hkl=[111]

